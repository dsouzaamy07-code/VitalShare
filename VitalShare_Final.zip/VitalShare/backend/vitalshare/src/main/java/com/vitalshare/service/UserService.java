
package com.vitalshare.service;

import com.vitalshare.model.User;
import com.vitalshare.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> getUserById(Integer id) {
        return userRepository.findById(id);
    }

    public Optional<User> getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public boolean emailExists(String email) {
        return userRepository.existsByEmail(email);
    }

    // Register a new user
    public User saveUser(User user) {

        if (emailExists(user.getEmail())) {
            throw new IllegalArgumentException("Email already registered.");
        }

        user.setPasswordHash(
                passwordEncoder.encode(user.getPasswordHash())
        );

        return userRepository.save(user);
    }

    // Login and verify password
    public Optional<User> login(String email, String password) {

        Optional<User> result = userRepository.findByEmail(email);

        if (result.isEmpty()) {
            return Optional.empty();
        }

        User user = result.get();
        String storedPassword = user.getPasswordHash();

        // Check whether the password is already BCrypt encrypted
        if (storedPassword != null &&
                (storedPassword.startsWith("$2a$") ||
                        storedPassword.startsWith("$2b$") ||
                        storedPassword.startsWith("$2y$"))) {

            if (passwordEncoder.matches(password, storedPassword)) {
                return Optional.of(user);
            }

            return Optional.empty();
        }

        // Support existing demo accounts with old plain-text passwords
        if (storedPassword != null && storedPassword.equals(password)) {

            user.setPasswordHash(passwordEncoder.encode(password));
            userRepository.save(user);

            return Optional.of(user);
        }

        return Optional.empty();
    }

    // Update profile without changing the existing password
    public Optional<User> updateUser(Integer id, User updatedUser) {

        Optional<User> result = userRepository.findById(id);

        if (result.isEmpty()) {
            return Optional.empty();
        }

        User existingUser = result.get();

        if (!existingUser.getEmail().equals(updatedUser.getEmail())
                && emailExists(updatedUser.getEmail())) {
            throw new IllegalArgumentException("Email already registered.");
        }

        existingUser.setFullName(updatedUser.getFullName());
        existingUser.setEmail(updatedUser.getEmail());

        return Optional.of(userRepository.save(existingUser));
    }

    public void deleteUser(Integer id) {
        userRepository.deleteById(id);
    }
}
